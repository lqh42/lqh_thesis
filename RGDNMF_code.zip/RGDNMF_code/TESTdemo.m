clc
clear;
close all;
% 'Test_1_Zeisel_big',
dataset = {'Test_Kolod','Test_Darmanis','Test_Ramskold', 'Test_human', 'Test_islet','Test_Zheng', ...
    'GSE57249','GSE64016','GSE70657','Armstrong','bhattacharjee','lapointe','nutt','pomeroy',...
    'Quake_10x_Limb_Muscle', 'GSE81252','GSE75688','GSE85908','Quake_10x_Limb_Muscle','Test_1_Zeisel_big'};
addpath('./data')
ndata = length(dataset);
collect_result_NMI = zeros(7,ndata);
collect_result_ARI = zeros(7,ndata);
collect_result_ACC = zeros(7,ndata);
collect_result_Purity = zeros(7,ndata);

data_num = [1,3,4,5,7,8,9,16,17,18,19,20];




for i = 10:10
    
    
    load(dataset{data_num(i)});
    nnClass = length(unique(true_labs)); 
    X = in_X';
    nsmp = size(X,2);
    X = NormalizeFea(X);
%     X = normalize(X);
    nfeature = floor(sqrt(nsmp));
    NMI = zeros(7,6);
    ARI = zeros(7,6);
    ACC = zeros(7,6);
    Purity = zeros(7,6);
    for j = 1:1
        fprintf('time: %d',j);
  
    %% kmeans聚类
% %     dis=pdist(He);
% %     WW=squareform(dis);
%     [project_labs, center] = litekmeans(X', nnClass);
% 
%     NMI(1,j) = Cal_NMI(true_labs, project_labs);
%     ARI(1,j) = Cal_ARI(true_labs, project_labs);
%     ACC(1,j) = ACC_ClusteringMeasure(true_labs, project_labs);
%     [Entropy,Purity0,FMeasure,Accuracy] = Fmeasure(true_labs', project_labs');
%     Purity(1,j) = Purity0;
% % %     [project_labs, kerNS] = SpectralClustering(WW,nnClass);

%% tsne
% 
%     addpath('./tSNE_matlab')
%     X = full(X);
%     ydata = tsne(X', true_labs, nfeature,28);
% 
%     [project_labs, center] = litekmeans(ydata, nnClass);
% 
%     NMI(2,j) = Cal_NMI(true_labs, project_labs);
%     ARI(2,j) = Cal_ARI(true_labs, project_labs);
%     ACC(2,j) = ACC_ClusteringMeasure(true_labs, project_labs);
%     [Entropy,Purity0,FMeasure,Accuracy] = Fmeasure(true_labs', project_labs');
%     Purity(2,j) = Purity0;
%% SC

%     addpath('./spectralClustering')
% 
%     sigma = 10;
%     % W = DataProjection(X,nsmp);
% 
%     Z=pdist(X');
%     W=squareform(Z);
%     % affine = false;
%     project_labs = spectral(W, sigma, nnClass);
%     
%     NMI(3,j) = Cal_NMI(true_labs, project_labs);
%     ARI(3,j) = Cal_ARI(true_labs, project_labs);
%     ACC(3,j) = ACC_ClusteringMeasure(true_labs, project_labs);
%     [Entropy,Purity0,FMeasure,Accuracy] = Fmeasure(true_labs', project_labs');
%     Purity(3,j) = Purity0;
%% SSC
%     addpath('./SSC-using-ADMM-master')
%     sigma=1;
% 
%     Z=pdist(X');
%     W=squareform(Z);
%     affine = false;
% 
%     [err, CMat, project_labs] = SSC(W,sigma, affine,20,false,1,true_labs');
%    
%     NMI(4,j) = Cal_NMI(true_labs, project_labs);
%     ARI(4,j) = Cal_ARI(true_labs, project_labs);
%     ACC(4,j) = ACC_ClusteringMeasure(true_labs, project_labs);
%     [Entropy,Purity0,FMeasure,Accuracy] = Fmeasure(true_labs', project_labs');
%     Purity(4,j) = Purity0;
%% SIMLR
%     addpath('./SIMLR')
%     addpath('./SIMLR/src')
%     [project_labs, S, F, ydata,alpha] = SIMLR(X',nnClass,10);
% 
%     NMI(5,j) = Cal_NMI(true_labs, project_labs);
%     ARI(5,j) = Cal_ARI(true_labs, project_labs);
%     ACC(5,j) = ACC_ClusteringMeasure(true_labs, project_labs);
%     [Entropy,Purity0,FMeasure,Accuracy] = Fmeasure(true_labs', project_labs');
%     Purity(5,j) = Purity0;
%% SinNLRR

    addpath('./SinNLRR-master')
    [NMI0,ARI0,project_labs,similarity] = SinNLRR(X',true_labs);

    NMI(6,j) = Cal_NMI(true_labs, project_labs);
    ARI(6,j) = Cal_ARI(true_labs, project_labs);
    ACC(6,j) = ACC_ClusteringMeasure(true_labs, project_labs);
    [Entropy,Purity0,FMeasure,Accuracy] = Fmeasure(true_labs', project_labs');
    Purity(6,j) = Purity0;
%% PCA
% %     X = full(X);
%     [coeff, score] = pca(X');
%     [project_labs, center] = litekmeans(score, nnClass);
%     
%     NMI(7,j) = Cal_NMI(true_labs, project_labs);
%     ARI(7,j) = Cal_ARI(true_labs, project_labs);
%     ACC(7,j) = ACC_ClusteringMeasure(true_labs, project_labs);
%     [Entropy,Purity0,FMeasure,Accuracy] = Fmeasure(true_labs', project_labs');
%     Purity(7,j) = Purity0;
    %% GNMF
%     addpath('./Tools')
%     options = [];
%     options.NeighborMode = 'KNN';
%     options.k = 5;
%     options.WeightMode = 'HeatKernel';
%     options.t = 1;
% 
%     W = constructW(X',options);%nnSWM1(X,X,5,1,0);
% 
%     options = [];
%     options.error = 0.005;
%     options.maxIter = 500;
%     options.nRepeat = 1;
%     options.minIter = 20;
%     options.meanFitRatio = 0.5;
%     options.alpha = 10;
% %     U = [];
% %     V = [];
%     
%     k = floor(sqrt(nsmp));
%     [U, V] = nmf(X,k,200);
%     
%     [Ze, He] = GNMF_Multi(X, k, W, options,U, V');
%     [project_labs, center] = litekmeans(He, nnClass);
%     
    
    
    % 

    %% 评估
%     NMI(j) = Cal_NMI(true_labs, project_labs);
%     ARI(j) = Cal_ARI(true_labs, project_labs);


    end
%     eval(['save', ' ', './plot/B_Graph_', dataset{data_num(i)},'_' num2str(i), '.mat', ' ', 'true_labs CMat similarity score X'])
% 
    collect_result_NMI(:,i) = mean(NMI,2);
    collect_result_ARI(:,i) = mean(ARI,2);
    collect_result_ACC(:,i) = mean(ACC,2);
    collect_result_Purity(:,i) = mean(Purity,2);
end