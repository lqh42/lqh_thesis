import argparse
import os
import tensorflow as tf
from Network.Trainer import Trainer
import process
import numpy as np
import scipy.io as sio
from utils import load_data, load_graph, buildGraphNN
import random
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler,MinMaxScaler   #实现z-score标准化
import pandas as pd

# import 单细胞相关库
from lib import preprocessH5
# from torch_geometric.utils import to_undirected, add_self_loops, from_scipy_sparse_matrix
from sklearn.metrics.cluster import normalized_mutual_info_score
from sklearn.metrics.cluster import adjusted_rand_score
from sklearn import metrics
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt


import seaborn as sns

def parse_args():
    """
    Parses the arguments.
    """
    parser = argparse.ArgumentParser(description="Run gate.")
    # 数据集
    parser.add_argument('--dataset', nargs='?', default='Quake_Smart-seq2_Limb_Muscle', help='Input dataset')

    # 数据参数
    parser.add_argument('--cell_num', type=int, help='The number of cell.')
    parser.add_argument('--cluster_num', type=int, help='The number of cell type.')
    parser.add_argument('--gene_num', default=1000, type=int, help='The number of gene.')
    parser.add_argument('--k_NN', default=50, type=int, help='The number of KNN.')

    # 训练参数
    parser.add_argument('--seed', type=int, default=30)  # 33
    parser.add_argument('--lr', type=float, default=3e-3, help='Learning rate. Default is 0.001.')
    parser.add_argument('--n-epochs', default=30, type=int, help='Number of epochs')
    parser.add_argument('--hidden-dims-1', type=list, nargs='+', default=[512, 256], help='Number of dimensions1.')
    parser.add_argument('--hidden-dims-2', type=list, nargs='+', default=[512, 256], help='Number of dimensions1.')

    parser.add_argument('--lambda-', default=1, type=float, help='Parameter controlling the contribution of edge '
                                                                   'Graph reconstruction in the loss function.')
    parser.add_argument('--lambda-1', default=0, type=float, help='Parameter controlling the contribution of features_loss.')
    parser.add_argument('--lambda-2', default=1, type=float, help='Parameter controlling the contribution of SE_loss.')
    parser.add_argument('--lambda-3', default=1e-2, type=float, help='Parameter controlling the contribution of consistent_loss.')
    parser.add_argument('--lambda-4', default=1, type=float, help='Parameter controlling the contribution of S_Regular.')
    parser.add_argument('--lambda-5', default=5, type=float, help='Parameter controlling the contribution of Cq_loss.')
    parser.add_argument('--lambda-6', default=5, type=float, help='Parameter controlling the contribution of dense_loss.')
    parser.add_argument('--lambda-7', default=1e-2, type=float, help='Parameter controlling the contribution of zinb_loss1.')
    parser.add_argument('--lambda-8', default=1e-2, type=float, help='Parameter controlling the contribution of zinb_loss2.')

    parser.add_argument('--dropout', default=0.0, type=float, help='Dropout.')
    parser.add_argument('--gradient_clipping', default=3.0, type=float, help='gradient clipping')
    return parser.parse_args()


def main(args):
    """
    Load HARR Dataset.
    """
    if args.dataset in {'hhar'}:
        # 读取原始数据
        dataset = load_data('hhar')
        # 读取图数据
        G = load_graph('hhar', 5)
        # 读取特征矩阵
        X = dataset.x
        # 读取标签数据
        Label = dataset.y

        # 读取视图2的特征矩阵
        X2 = sio.loadmat('X2' + '.mat')
        X2_dict = dict(X2)
        X2 = X2_dict['X2']


    elif args.dataset in {'Quake_10x_Bladder', 'Quake_10x_Limb_Muscle', 'Quake_Smart-seq2_Diaphragm', 'Romanov',
                          'Young', 'Adam', 'Chen', 'Plasschaert', 'Quake_10x_Spleen', 'Quake_10x_Trachea',
                          'Quake_Smart-seq2_Heart', 'Quake_Smart-seq2_Limb_Muscle', 'Quake_Smart-seq2_Lung', 'Klein',
                          'Muraro', 'Pollen', 'Tosches_turtle', 'Wang_Lung'}:

        dataPath = "/Users/lqh/Desktop/DeepLearningCode/Data/SingleCell_h5_Data"
        # dataPath = "../../../Dataset/SingleCell_h5_Data"
        # dataPath = "../../Data/SingleCell_h5_Data"
        # dataPath = "../../scRNAseqData"

        filename = dataPath + "/" + args.dataset + "/data.h5"

        X, Label, _,X_row, _, _ = preprocessH5.load_h5(filename, args.gene_num)
        # X2, _, _, _, _ = preprocessH5.load_h5(filename, None)
        pca = PCA(n_components=X.shape[1])
        X2 = pca.fit_transform(X_row)

        b_test = MinMaxScaler()  # 训练数据，赋值给b_test
        X2 = b_test.fit_transform(X2)

        G = buildGraphNN(X, args.k_NN)
    #
    # #     绘制热力图
    #     g = sns.clustermap(pd.DataFrame(X_row),center=0, yticklabels=False, camp = 'RdBu')
    #
    #     print(g)
    #     plt.show()


    # prepare the data
    # 处理图数据：添加self-loop,s:元素为1的行索引，R：元素为1的列索引
    G_tf, S, R = process.prepare_graph_data(G)
    # 视图2的图结构=视图1的图结构
    G_tf2 = G_tf
    # 视图2的图元素索引
    S2 = S
    R2 = R

    # add feature dimension size to the beginning of hidden_dims
    feature_dim1 = X.shape[1]
    args.hidden_dims_1 = [feature_dim1] + args.hidden_dims_1
    feature_dim2 = X2.shape[1]
    args.hidden_dims_2 = [feature_dim2] + args.hidden_dims_2
    args.cell_num = X.shape[0]
    args.cluster_num = len(np.unique(Label))
    print('Dim_hidden_1: ' + str(args.hidden_dims_1))
    print('Dim_hidden_2: ' + str(args.hidden_dims_2))
    trainer = Trainer(args)
    coef,y_pred = trainer(G_tf, G_tf2, X, X2, S, S2, R, R2, Label)

    # # 绘制聚类图
    # tsne = TSNE(n_components=2, random_state=0)
    #
    # X_tsne = tsne.fit_transform(coef)
    #
    # plt.figure(figsize=(5, 5))
    # # plt.subplot(121)
    # labelliat = np.unique(y_pred)
    # plt.scatter(X_tsne[:, 0], X_tsne[:, 1], c=y_pred, s=4, alpha=None, marker='o', edgecolors=None)
    # # plt.scatter(X_tsne[:, 0], X_tsne[:, 1], c=y_pred, label=labelliat)
    # # plt.legend()
    # imagePath = './images/' + args.dataset + '_scGAEMC.png'
    # plt.savefig(imagePath, dpi=120)
    # plt.show()


def setup_seed(seed):
    np.random.seed(seed)
    random.seed(seed)
    # tf.set_random_seed(seed)
    tf.random.set_seed(args.seed)


if __name__ == "__main__":
    args = parse_args()
    os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
    os.environ["CUDA_VISIBLE_DEVICES"] = "0,1"
    my_tf_seed = args.seed
    setup_seed(my_tf_seed)
    main(args)
