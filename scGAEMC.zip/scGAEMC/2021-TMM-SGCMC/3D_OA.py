#根据radix和cardinal的变化绘制出3D表
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np

dataset = 'HUST2013'

# setup the figure and axes
#创建画布
fig = plt.figure(figsize=(5, 5))  # 画布宽长比例
#创建单个子图
#(111)就是构成1x1子图，第一个子图，234就是2x3个图中第4的子图
ax = fig.add_subplot( projection='3d')#得到一个axes3d对象
if dataset =='IP':
    ax.set_title('Indian Pines',fontname='times new roman',fontsize=20,
                  weight='bold',style='italic')
elif dataset == 'Loukia':
    ax.set_title("Loukia",fontname='times new roman',fontsize=20,
                 weight='bold',style='italic')
elif dataset == 'HUST2013':
    ax.set_title("Houston 2013", fontname='times new roman', fontsize=20,
                 weight='bold', style='italic')

Cardinal = ['2','4','8']
Radix = ['2','3','4']

OA = None

if dataset =='IP':
    #一行是我们的数据竖着输入
    OA = np.array([[89.51, 88.50, 88.58],  # radix=1
                   [89.41, 87.78, 89.24],  # radix=2
                   [89.82, 89.80, 88.23]  # radix=3
                   ])
elif dataset == 'Loukia':
    OA = np.array([[78.47, 77.26, 77.17],  # radix=1
                   [76.28, 77.63, 75.81],  # radix=2
                   [78.32, 75.56, 74.75]  # radix=3
                   ])

elif dataset == 'HUST2013':
    OA = np.array([[95.16, 94.71, 94.64],  # radix=1
                   [94.60, 93.48, 93.57],  # radix=2
                   [96.12, 94.33, 93.50]  # radix=3
                   ])

width = depth = 0.5#柱体x,y方向的宽厚

dcolor = 0 #随着值的变化，颜色变化的程度
bottom = 0  #Z轴起始位置

if dataset == 'IP':
    dcolor = 70  # 随着值的变化，颜色变化的程度
    bottom = 87  # Z轴起始位置
elif dataset == 'Loukia':
    dcolor = 50  # 随着值的变化，颜色变化的程度
    bottom = 74  # Z轴起始位置

elif dataset == 'HUST2013':
    dcolor = 45  # 随着值的变化，颜色变化的程度
    bottom = 91  # Z轴起始位置

#画0A
#i为Radix，j为Cardinal
for i in range(len(Radix)):
    for j in range(len(Cardinal)):
        z = OA[i][j] -bottom#该柱的高
        print(z)
        color = np.array([200, 70, 255-z*dcolor])/255.0#颜色 其中每个元素在0~1之间
        ax.bar3d(i-0.25, j-0.25,bottom, width, depth, z, color=color)   #每次画一个柱


ax.set_xlabel('Radix',fontname='times new roman',fontsize=15)
ax.set_ylabel('Cardinal',fontname='times new roman',fontsize=15)
ax.set_zlabel('Overrall Accuracy(%)',fontname='times new roman',fontsize=15)


plt.xticks(range(len(Radix)),Radix)
plt.yticks(range(len(Cardinal)),Cardinal)

if dataset == 'IP':
    plt.savefig('./IP_Cardinal_Radix_OA.png',dpi=800,format='png')
elif dataset == 'Loukia':
    plt.savefig('./Loukia_Cardinal_Radix_OA.png',dpi=800,format='png')
elif dataset == 'HUST2013':
    plt.savefig('./HUST_Cardinal_Radix_OA.png',dpi=800,format='png')

plt.show()
