#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2023/2/9
# @Author  : 小龙人
# @Github  : https://github.com/lqh42
# @Software: PyCharm
# @File    : model.py

import torch
# from torch.autograd import Variable

import torch.nn as nn
import numpy as np
from torch.nn.parameter import Parameter
from GNN import GNNLayer, GraphConvolution
import torch.utils.data as Data

if torch.cuda.is_available():
    print('cuda availabel')
    dtypeFloat = torch.cuda.FloatTensor
    dtypeLong = torch.cuda.LongTensor
    torch.cuda.manual_seed(1)
else:
    print('cuda not availabel')
    dtypeFloat = torch.FloatTensor
    dtypeLong = torch.LongTensor
    torch.manual_seed(1)


# from coarsening import lmax_L
# from coarsening import rescale_L


class my_sparse_mm(torch.autograd.Function):
    """
    Implementation of a new autograd function for sparse variables,
    called "my_sparse_mm", by subclassing torch.autograd.Function
    and implementing the forward and backward passes.
    """

    def forward(self, W, x):  # W is SPARSE
        self.save_for_backward(W, x)
        y = torch.mm(W, x)
        return y

    def backward(self, grad_output):
        W, x = self.saved_tensors
        grad_input = grad_output.clone()
        grad_input_dL_dW = torch.mm(grad_input, x.t())
        grad_input_dL_dx = torch.mm(W.t(), grad_input)
        return grad_input_dL_dW, grad_input_dL_dx


#########################################################################################################


def _nan2zero(x):
    return torch.where(torch.isnan(x), torch.zeros_like(x), x)


def _nan2inf(x):
    return torch.where(torch.isnan(x), torch.zeros_like(x) + np.inf, x)


def NB(theta, y_true, y_pred, mask=False, debug=False, mean=True):
    eps = 1e-10
    scale_factor = 1.0

    t1 = torch.lgamma(theta + eps) + torch.lgamma(y_true + 1.0) - torch.lgamma(y_true + theta + eps)
    t2 = (theta + y_true) * torch.log(1.0 + (y_pred / (theta + eps))) + (
            y_true * (torch.log(theta + eps) - torch.log(y_pred + eps)))

    final = t1 + t2
    final = _nan2inf(final)
    if mean:
        final = torch.mean(final)
    else:
        final = torch.sum(final)

    return final


def ZINB(pi, theta, y_true, y_pred, ridge_lambda, mask=False, debug=False, mean=True):
    eps = 1e-10
    scale_factor = 1.0
    nb_case = NB(theta, y_true, y_pred, mean=True, debug=debug) - torch.log(1.0 - pi + eps)

    zero_nb = torch.pow(theta / (theta + y_pred + eps), theta)
    zero_case = -torch.log(pi + ((1.0 - pi) * zero_nb) + eps)
    result = torch.where(torch.le(y_true, 1e-8), zero_case, nb_case)
    ridge = ridge_lambda * torch.pow(pi, 2)
    result += ridge
    if mean:
        result = torch.mean(result)
    else:
        result = torch.sum(result)

    result = _nan2inf(result)

    return result



# 构建细胞的网络：AutoEncoder，全链接自编码器
def buildNetwork_cell(layers, activation="relu", dropout=0):
    net = []
    for i in range(1, len(layers)):
        net.append(nn.Linear(layers[i - 1], layers[i]))
        if activation == "relu":
            net.append(nn.ReLU())
        elif activation == "sigmoid":
            net.append(nn.Sigmoid())
        if dropout > 0:
            net.append(nn.Dropout(dropout))
    return nn.Sequential(*net)


# 构建基因的网络：GraphAutoEncoder，图自编码器
def buildNetwork_gene(layers, activation="relu", dropout=0):
    net = []
    for i in range(1, len(layers)):
        net.append(GraphConvolution(layers[i - 1], layers[i]))
        if activation == "relu":
            net.append(nn.ReLU())
        elif activation == "sigmoid":
            net.append(nn.Sigmoid())
        if dropout > 0:
            net.append(nn.Dropout(dropout))
    return nn.Sequential(*net)



class DeepCI_Cell(nn.Module):

    def __init__(self, cellInput_dim=784, geneInput_dim=784, z_dim=10, n_clusters=10,
                 cellEncodeLayer=[400], cellDecodeLayer=[400], geneEncodeLayer=[400], geneDecodeLayer=[400],
                 activation="relu", dropout=0, alpha=1., rec_gamma=1,clu_gamma=1,cell_gamma=1,gene_gamma=1):
        super(DeepCI_Cell, self).__init__()

        self.activation = activation
        self.dropout = dropout
        # 细胞自编码器，自监督模块
        self.cellencoder = buildNetwork_cell([cellInput_dim] + cellEncodeLayer, activation=activation, dropout=dropout)
        self.celldecoder = buildNetwork_cell(cellDecodeLayer, activation=activation, dropout=dropout)
        self._enc_mu = nn.Linear(cellEncodeLayer[-1], z_dim)
        self._dec = nn.Linear(cellDecodeLayer[-1], cellInput_dim)

        # 基因自编码器
        self.geneencoder = buildNetwork_gene([geneInput_dim] + geneEncodeLayer, activation=activation, dropout=dropout)
        self.genedecoder = buildNetwork_gene(geneDecodeLayer, activation=activation, dropout=dropout)
        self._dec_gene = nn.Linear(geneDecodeLayer[-1], geneInput_dim)

        # 相关参数
        self.n_clusters = n_clusters
        self.alpha = alpha
        self.rec_gamma = rec_gamma
        self.clu_gamma = clu_gamma
        self.cell_gamma = cell_gamma
        self.gene_gamma = gene_gamma
        self.mu = Parameter(torch.Tensor(n_clusters, z_dim))

    def forward(self, celltogene, genetocell, adj):
        # 细胞编码器
        cell_emb = self.cellencoder(celltogene)
        # 细胞低维表示
        z = self._enc_mu(cell_emb)
        # 细胞解码器
        cell_h = self.celldecoder(cell_emb)
        # 细胞重构
        cellrecon = self._dec(cell_h)
        # 求解自监督q
        q = self.soft_assign(z)

        # 基因编码器
        gene_emb = self.geneencoder(genetocell,adj)
        # 基因解码器
        gene_h = self.genedecoder(gene_emb,adj)
        # 基因重构
        generecon = self._dec_gene(gene_h)

        # NMF重构基因表达矩阵
        xrecon = torch.mm(cell_emb, torch.t(gene_emb))

        return xrecon, cell_emb, gene_emb, z, q, cellrecon, generecon

    def soft_assign(self, z):
        q = 1.0 / (1.0 + torch.sum((z.unsqueeze(1) - self.mu)**2, dim=2) / self.alpha)## z.unsqueeze(1)这个函数主要是对数据维度进行扩充，变成二维了，行数*1列
        q = q**(self.alpha+1.0)/2.0
        q = q / torch.sum(q, dim=1, keepdim=True)
        return q

    def loss_function(self, x, xrecon, p, q, matrix_mask, cellrecon, generecon, input_cell, input_gene):
        def kld(target, pred):
            return torch.mean(torch.sum(target * torch.log(target / (pred + 1e-6)), dim=1))

        kldloss = kld(p, q)
        recon_loss = torch.mean((x - (torch.mul(xrecon, matrix_mask))) ** 2)
        cell_loss = torch.mean((input_cell - cellrecon) ** 2)
        gene_loss = torch.mean((input_gene - generecon) ** 2)
        loss = self.rec_gamma * recon_loss + self.clu_gamma * kldloss + self.cell_gamma * cell_loss + self.gene_gamma * gene_loss
        return loss

    def target_distribution(self, q):
        p = q ** 2 / torch.sum(q, dim=0)
        p = p / torch.sum(p, dim=1, keepdim=True)
        return p

    def encodeBatch(self, loader_cell):
        use_cuda = torch.cuda.is_available()
        if use_cuda:
            self.cuda()

        # loader_cell = Data.DataLoader(
        #     dataset=X,  # torch TensorDataset format
        #     batch_size=Cell_BATCH_SIZE,  # mini batch size
        #     shuffle=False,  # random shuffle for training
        #     num_workers=0,  # subprocesses for loading data
        # )
        # loader_cell

        encoded_z = []
        self.eval()

        for step_cell, batch_cell in enumerate(loader_cell):  # for each training step

            [_, _, _, z, _, _, _] = self.forward(batch_cell, torch.t(X))

            encoded_z.append(z.data)
            encoded = torch.cat(encoded_z, dim=0)
        return encoded





if __name__ == "__main__":
    # Hyper Parameters
    Cell_BATCH_SIZE = 512
    Gene_BATCH_SIZE = 1024
    lr = 0.0001
    EPOCH = 400
    update_interval = 5
    tol = 1e-4

    z_dim = 32
    rec_gamma = 1
    clu_gamma = 1
    cell_gamma = 1
    gene_gamma = 1
    alpha = 1
    idec = DeepCI_Cell(1200, 2000, z_dim, 4, cellEncodeLayer=[64, 32], cellDecodeLayer=[32, 64],
               geneEncodeLayer=[64, 32], geneDecodeLayer=[32, 64],
               activation="relu", dropout=0.1, alpha=alpha, rec_gamma=rec_gamma, clu_gamma=clu_gamma,
               cell_gamma=cell_gamma,
               gene_gamma=gene_gamma)
    print(idec)