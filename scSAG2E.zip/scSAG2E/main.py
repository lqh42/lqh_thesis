#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2023/2/9
# @Author  : 小龙人
# @Github  : https://github.com/lqh42
# @Software: PyCharm
# @File    : main.py
import argparse
import logging
import sys
import os
from os import mkdir

import numpy as np
import torch
import random

# 面向单细胞聚类分析的特征表示方法研究

# from lib.utils import load
from torch.optim import Adam

from function.test_function import test
from function.train_function import train
from lib import preprocessH5
from lib.dataClass import Dataload
from lib.utils import buildGraphNN, normalize, sparse_mx_to_torch_sparse_tensor
from model.model import *
from torch.utils.data import DataLoader, TensorDataset


# from fvcore.nn import  parameter_count_table


def get_model(args, model_name):
    layer1 = args.layer1
    layer2 = args.layer2
    layer3 = args.layer3
    n_input = args.n_input
    # n_z = args.n_z
    n_clusters = args.n_clusters
    # distribution = args.distribution
    lr = args.lr

    # if model_name == "DGCNb":
    #     model = DGCNb(layer1, layer2, layer3, layer3, layer2, layer1, n_input=n_input, n_z=n_z,
    #                   n_clusters=n_clusters,
    #                   distribution=distribution,
    #                   v=1.0).to(device)
    if model_name == "DeepCI":
        model = DeepCI_Cell(enc=[layer1, layer2, layer3], n_input=n_input, n_gene=args.batchsize,
                            n_clusters=n_clusters).to(
            device)
    if model_name == " ":
        print("请输入模型名称")

    # optimizer = Adam(model.parameters(), lr=lr)
    # scheduler = lr
    optimizer = Adam(model.parameters(), lr=lr, weight_decay=0)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=20, gamma=0.5)
    # optimizer = torch.optim.SGD(model.parameters(), args.learning_rate, args.momentum, args.weight_decay)
    # scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lambda epoch: 1 - (epoch / args.epochs))
    return model, optimizer, scheduler


def load(dataPath, dataset, num_gene, batchsize):
    """
    :param dataPath: 数据所在路径
    :param dataset: 数据集名称
    :param num_gene: 主要基因个数
    :param batchsize: batch 大小
    :return:
    train_: 训练数据集
    train_:测试数据集
    count_X: 原始计量数据
    size_factor：首先计算所有细胞中每个基因的几何平均值，每个细胞的size factor是基因表达与基因几何平均值比值的中位数。
    cluster_number: 类别个数
    """

    # 数据读取
    filename = dataPath + "/" + dataset + "/data.h5"
    X, Y, count_X, size_factor, cluster_number = preprocessH5.load_h5(filename, num_gene)

    # 生成细胞视图和基因视图
    Cell_X = torch.Tensor(X).to(args.device)
    Gene_X = Cell_X.t().to(args.device)

    # 计算阶段数据
    Cell_num = len(Y)
    Cell_train_num = round(Cell_num * 0.4)
    Cell_val_num = round(Cell_num * 0.3) + Cell_train_num

    Gene_train_num = round(num_gene * 0.4)
    Gene_val_num = round(num_gene * 0.4) + Gene_train_num

    # 生成训练数据集
    train_Cell = Cell_X[0:Cell_val_num, :]
    train_Y = torch.tensor(Y[0:Cell_val_num])
    train_Gene = Gene_X[0:Gene_train_num, :]

    # 生成数据类
    # train_load = Dataload(data=train_X, label=train_Y)
    Cell_load = TensorDataset(train_Cell, train_Y)
    Gene_load = TensorDataset(train_Gene)

    Cell_train_data = DataLoader(dataset=Cell_load,
                                 batch_size=batchsize,
                                 shuffle=True,
                                 drop_last=True)

    Gene_train_data = DataLoader(dataset=Gene_load,
                                 batch_size=batchsize,
                                 shuffle=True,
                                 drop_last=True)

    # 生成验证数据集
    val_Cell = Cell_X[Cell_train_num:Cell_val_num, :]
    val_Y = Y[Cell_train_num:Cell_val_num]
    val_Gene = Gene_X[Gene_train_num:Gene_val_num, :]

    # 生成数据类
    # val_load = Dataload(data=val_X, label=val_Y)
    Cell_val_load = TensorDataset(val_Cell, torch.tensor(val_Y))
    Gene_val_load = TensorDataset(val_Gene)

    Cell_val_data = DataLoader(dataset=Cell_val_load,
                               batch_size=batchsize,
                               shuffle=True,
                               drop_last=True)

    Gene_val_data = DataLoader(dataset=Gene_val_load,
                               batch_size=batchsize,
                               shuffle=True,
                               drop_last=True)

    # 生成测试数据集
    Cell_test_X = Cell_X[Cell_val_num:Cell_num, :]
    test_Y = Y[Cell_val_num:Cell_num]
    Gene_test_X = Gene_X[Gene_val_num:num_gene, :]

    # 生成数据类
    # test_load = Dataload(data=test_X, label=test_Y)
    Cell_test_load = TensorDataset(Cell_test_X, torch.tensor(test_Y))
    Gene_test_load = TensorDataset(Gene_test_X)
    Cell_test_data = DataLoader(dataset=Cell_test_load,
                                batch_size=batchsize,
                                shuffle=True,
                                drop_last=True)
    Gene_test_data = DataLoader(dataset=Gene_test_load,
                                batch_size=batchsize,
                                shuffle=True,
                                drop_last=True)

    # return Cell_train_data, Gene_train_data, Cell_val_data, Gene_val_data, Cell_test_data, Gene_test_data, count_X, size_factor, cluster_number
    return Cell_train_data, Gene_train_data, Cell_val_data, Gene_val_data, Cell_test_data, Gene_test_data


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


def init():
    device = torch.device("cuda" if args.cuda else "cpu")

    _, _, _, _, _, cluster_number = load(args.dataPath, args.dataset, args.num_gene, args.batchsize)

    args.n_clusters = cluster_number
    args.n_input = args.num_gene

    kwargs = {"lr": args.lr,
              "epochs": args.epochs,
              "lambda1": args.lambda1,
              "alpha": args.alpha,
              "mu": args.mu,
              "beta": args.beta,
              "layer1": args.layer1,
              "layer2": args.layer2,
              "layer3": args.layer3,
              "neighborK": args.neighborK,
              "n_input": args.num_gene,
              "n_z": args.n_z,
              "n_clusters": args.n_clusters,
              "distribution": args.distribution,
              "tag": args.model_tag,
              "device": device
              }
    return kwargs


def main(config):
    # =================== 参数初始化 ======================
    kwargs = init()

    # ===================== data load =====================

    Cell_train_data, Gene_train_data, Cell_val_data, Gene_val_data, Cell_test_data, Gene_test_data = load(
        config.dataPath, config.dataset, config.num_gene, config.batchsize)
    # ==================== train ===========================
    seeds = [0, 20, 123, 200]
    item = 0
    final_model = None
    final_ACC = 0
    final_AA = 0
    final_kappa = 0
    final_report = 0
    OA_list = []
    for seed in seeds:
        item = item + 1
        setup_seed(seed)
        kwargs = init()

        # 获取细胞的模型
        model_cell, optimizer, scheduler = get_model(args, args.model_tag)
        model_cell = model_cell.to(args.device)

        # 预训练步骤


        # 训练模型
        iter_model = train(args, item=item, model=model_cell, Cell_train_loader=Cell_train_data,
                           Gene_train_loader=Gene_train_data, optimizer=optimizer,
                           scheduler=scheduler)

        # 测试模型
        iter_ACC, iter_AA, iter_kappa, iter_report, iter_Result = test(args, item, Cell_test_data, Gene_test_data,
                                                                       iter_model)
        OA_list.append(iter_ACC)

        # iter_Result_q
        # 保存最优迭代模型
        if final_ACC < iter_ACC:
            final_ACC = iter_ACC
            print("Best OA by now")
            final_model = iter_model  # 注意要保存当次迭代模型
            final_AA = iter_AA
            final_kappa = iter_kappa
            final_report = iter_report
            final_Result = iter_Result
        # print("X", train_, train_Y, train_adj)

        # 统计模型参数量
        print('======================================================')
        num_params = sum(param.numel() for param in final_model.parameters())
        print("模型参数量：")
        print(num_params)
        print("模型参数量核算：")
        # print(parameter_count_table(final_model))

        print("================Final 整体测试集上的报告=================")
        print(OA_list)
        print(final_report)
        print("Final整体测试集上的ACC:{}".format(final_ACC))
        print("Final整体测试集上的AA:{}".format(final_AA))
        print("Final整体测试集上的kappa系数:{}".format(final_kappa))

        print("================多个评价指标_p=================")
        print(final_Result)
        print("================多个评价指标_q=================")
        print("lr:", args.lr)
        print("lambda1:", args.lambda1)
        print("alpha:", args.alpha)
        print("mu:", args.mu)
        print("beta:", args.beta)

        # 保存最终模型
        path = './model_pth/' + args.dataset
        isExists = os.path.exists(path)
        if not isExists:
            mkdir(path)
        save_path = path + '/' + args.dataset + '_ ' + args.model_tag + '.pth'
        torch.save(final_model, save_path)
        print('模型已保存')

    return final_Result


if __name__ == '__main__':

    parser = argparse.ArgumentParser()

    # dataset hyper-parameters

    parser.add_argument('--dataset', type=str, default='Quake_10x_Limb_Muscle')  # Quake_10x_Limb_Muscle
    parser.add_argument('--dataPath', type=str, default='/Users/lqh/Desktop/DeepLearningCode/Data/SingleCell_h5_Data',
                        help='dataset path')
    # parser.add_argument('--dataPath', type=str, default='/home/lqh/lqh/Data', help='dataset path') ##服务器上的数据地址

    # model hyper-parameters
    parser.add_argument('--model_tag', type=str, default='DeepCI', help='method')
    parser.add_argument('--distribution', type=str, default='DeepCI')
    parser.add_argument('--num_gene', type=int, default=1000, help='# of genes')
    parser.add_argument('--epochs', type=int, default=300, help='# of epoch')  # 100    200 300
    parser.add_argument('--batchsize', type=int, default=256, help='# of genes')
    parser.add_argument('--lr', type=float, default=0.1)  # 学习率
    parser.add_argument('--testSize', default=0.2, type=float)  # 测试集占比
    parser.add_argument('--n_clusters', default=4, type=int)  # 聚类的数量
    parser.add_argument('--neighborK', default=20, type=int)  # K近邻的邻居个数

    # 损失函数系数
    parser.add_argument('--lambda1', type=float, default=1)  # 自监督系数 0.2
    parser.add_argument('--alpha', type=float, default=1)  # 特征重构系数 1  0.01
    parser.add_argument('--mu', type=float, default=1)  # ZINB损失系数 0.01 0.9
    parser.add_argument('--beta', type=float, default=1)  # 图重构系数 0.01 0.001

    # GNN的纬度数
    # 300 128 32
    parser.add_argument('--layer1', default=256, type=int)  # 128 64 32  //300 128 32 15
    parser.add_argument('--layer2', default=128, type=int)  # 128
    parser.add_argument('--layer3', default=32, type=int)
    parser.add_argument('--n_z', default=16, type=int)  # 输出的特征维度
    args = parser.parse_args()
    args.device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

    args.cuda = torch.cuda.is_available()
    print("use cuda: {}".format(args.cuda))
    log_format = '%(asctime)s %(message)s'
    logging.basicConfig(stream=sys.stdout, level=logging.INFO,
                        format=log_format, datefmt='%m/%d %I:%M:%S %p')
    logging.info(args)
    device = torch.device("cuda" if args.cuda else "cpu")

    datasetnames = ['Quake_10x_Bladder', 'Quake_10x_Limb_Muscle', 'Quake_Smart-seq2_Diaphragm', 'Romanov', 'Young',
                    'Adam', 'Bach', 'Chen', 'Plasschaert', 'Quake_10x_Spleen', 'Quake_10x_Trachea',
                    'Quake_Smart-seq2_Heart', 'Quake_Smart-seq2_Limb_Muscle', 'Quake_Smart-seq2_Lung', 'Klein',
                    'Muraro', 'Pollen', 'Tosches_turtle', 'Wang_Lung']

    for datasetname in datasetnames:
        args.dataset = datasetname
        print("============" + args.dataset + "=================")

        config = parser.parse_args()

        # 控制随机种子
        setup_seed(123)

        # 运行主程序
        final_Result = main(config)
        result_str = datasetname + '\n' + str(final_Result) + '\n'

        with open('result_GNN.txt', 'a') as f:  # 设置文件对象
            f.write(result_str)  # 可以是随便对文件的操作
