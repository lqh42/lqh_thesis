#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2023/11/9
# @Author  : 小龙人
# @Github  : https://github.com/lqh42
# @Software: PyCharm
# @File    : test.py
import numpy as np
from matplotlib import pyplot as plt
from sklearn.manifold import TSNE


def p(X,y_prred,name):
    X = X
    labels = y_prred
    tsne = TSNE(n_components=2, random_state=0)
    Y = tsne.fit_transform(X)
    x_min, x_max = Y.min(0), Y.max(0)
    X_norm = (Y - x_min) / (x_max - x_min)

    area = (20 * np.random.rand(len(Y))) ** 2
    color = []

    # for i in np.arange(len(labels)):
    #         if labels[i] == 1:
    #                 color.append('darkgreen')
    #         if labels[i] == 2:
    #                 color.append('darkorchid')
    #         if labels[i] == 3:
    #                 color.append('darkgoldenrod')
    #         if labels[i] == 4:
    #                 color.append('darkred')
    #         if labels[i] == 0:
    #                 color.append('royalblue')


    plt.scatter(Y[:, 0], Y[:, 1], c=color, s=4, alpha=None, marker='o', edgecolors=None)
    filename = name + '_kmeans' + '.pdf'
    plt.savefig(filename, format='pdf', bbox_inches='tight')

    plt.show()