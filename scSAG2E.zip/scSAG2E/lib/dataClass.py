#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2023/2/13
# @Author  : 小龙人
# @Github  : https://github.com/lqh42
# @Software: PyCharm
# @File    : dataClass.py
class Dataload:
    def __init__(self, cell, gene, label):
        self.cell = cell
        self.gene = gene
        self.label = label

    def __getitem__(self, index):
        return self.cell[index], self.gene[index], self.label[index]

    def __len__(self):
        return self.cell[0].size(0), self.gene[0].size(0)


