#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2023/7/16
# @Author  : 小龙人
# @Github  : https://github.com/lqh42
# @Software: PyCharm
# @File    : Rdata.py

import scipy.io as scio  # 需要用到scipy库
import numpy as np
import scipy

# my_data=np.arange(12) # 0-11
from lib import preprocessH5

dataPath = "/Users/lqh/Desktop/DeepLearningCode/Data/SingleCell_h5_Data"
dataset = "Quake_10x_Limb_Muscle"
# dataset = dataset_name
filename = dataPath + "/" + dataset + "/data.h5"
in_X, true_labs, _, _, _ = preprocessH5.load_h5(filename, 2000)
true_labs = true_labs.T
# 保存到当前路径下
scipy.io.savemat(
    '/Users/lqh/Desktop/龙清涵文件/01学习/04-导师安排任务/02论文书写/第一篇论文/RGNMF-DS_code/RGDNMF_code/newdata/' + 'Quake_10x_Limb_Muscle' + '.mat',
    mdict={'in_X': in_X, 'true_labs': true_labs})  # file_name.mat为保存的文件名。该保存的mat文件可直接在matlab打开
# 读取刚保存的.mat数据
# dict_ = scio.loadmat('file_name.mat')  # 输出的为dict字典类型
# data = dict_['data']  # 从字典中将数据取出
# print(type(dict_['data']))  # numpy.ndarray
