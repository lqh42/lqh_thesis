import h5py as h5
import sys

from lib import preprocessH5
from model.GNN import GraphConvolution

sys.path.append("..")
import torch.utils.data
from torchvision import datasets, transforms
import numpy as np
import scanpy as sc
import argparse
import random

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torch.utils.data as Data
# from sknetwork.clustering import Louvain, BiLouvain, modularity, bimodularity
from sklearn.metrics.cluster import normalized_mutual_info_score
from sklearn.metrics.cluster import adjusted_rand_score
from sklearn.cluster import KMeans
import sklearn
from sklearn import metrics
import pandas as pd
import time
from numpy.random import seed
from lib.utils import buildGraphNN, sparse_mx_to_torch_sparse_tensor
from lib.utils import normalize as normalized
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


def main(dataset_name):
    setup_seed(2)
    # seed(2)
    # torch.manual_seed(6)

    ## Note: this program need GPU to run ########

    #######  first change the data and label file path in your computer ########

    ### In the input, each row is a cell, and each column is a gene  #######
    # Data_file = "your data file path'
    # input = np.loadtxt(data_file, sep='\t')
    # input = np.array(input)
    # label_path = "your label file path"
    # y_true = np.loadtxt(label_path, delimiter='\t')

    dataPath = "/Users/lqh/Desktop/DeepLearningCode/Data/SingleCell_h5_Data"
    # dataset = "Quake_10x_Limb_Muscle"
    dataset = dataset_name
    filename = dataPath + "/" + dataset + "/data.h5"
    input, y_true, _, _, _ = preprocessH5.load_h5(filename, 2000)

    ##### Change the path to save the pretrained model in your computer #########
    save_path1 = 'save/' + dataset + '_cellautoencoder.pkl'
    save_path2 = 'save/' + dataset + '_geneautoencoder.pkl'

    ## buildnetwork
    def buildNetwork_cell(layers, activation="relu", dropout=0):
        net = []
        for i in range(1, len(layers)):
            net.append(nn.Linear(layers[i - 1], layers[i]))
            if activation == "relu":
                net.append(nn.ReLU())
            elif activation == "sigmoid":
                net.append(nn.Sigmoid())
            if dropout > 0:
                net.append(nn.Dropout(dropout))
        return nn.Sequential(*net)

    class CellAutoEncoder(torch.nn.Module):

        def __init__(self, cellInput_dim=784,
                     cellEncodeLayer=[400], cellDecodeLayer=[400], activation="relu", dropout=0):
            super(self.__class__, self).__init__()
            # self.z_dim = z_dim
            # self.cellLayers = [cellInput_dim] + cellEncodeLayer + [z_dim]
            self.activation = activation
            self.dropout = dropout
            self.cellencoder = buildNetwork_cell([cellInput_dim] + cellEncodeLayer, activation=activation,
                                                 dropout=dropout)
            self.celldecoder = buildNetwork_cell(cellDecodeLayer, activation=activation, dropout=dropout)
            # self._enc_mu = nn.Linear(cellEncodeLayer[-1], z_dim)
            self._dec = nn.Linear(cellDecodeLayer[-1], cellInput_dim)

            # self.n_clusters = n_clusters
            # self.alpha = alpha
            # self.gamma = gamma
            # self.mu = Parameter(torch.Tensor(n_clusters, z_dim))

        def forward(self, celltogene):
            h = self.cellencoder(celltogene)
            # z = self._enc_mu(h)
            h = self.celldecoder(h)
            xrecon = self._dec(h)
            # compute q -> NxK
            # q = self.soft_assign(z)
            return xrecon

    # def buildNetwork_gene(layers, activation="relu", dropout=0):
    #     net = []
    #     for i in range(1, len(layers)):
    #         net.append(nn.Linear(layers[i - 1], layers[i]))
    #         if activation == "relu":
    #             net.append(nn.ReLU())
    #         elif activation == "sigmoid":
    #             net.append(nn.Sigmoid())
    #         if dropout > 0:
    #             net.append(nn.Dropout(dropout))
    #     return nn.Sequential(*net)

    def buildNetwork_gene(layers, activation="relu", dropout=0):
        net = []
        for i in range(1, len(layers)):
            net.append(nn.Linear(layers[i - 1], layers[i]))
            if activation == "relu":
                net.append(nn.ReLU())
            elif activation == "sigmoid":
                net.append(nn.Sigmoid())
            if dropout > 0:
                net.append(nn.Dropout(dropout))
        return nn.Sequential(*net)

    class GeneAutoEncoder(torch.nn.Module):

        def __init__(self, geneInput_dim=784,
                     geneEncodeLayer=[400], geneDecodeLayer=[400], activation="relu", dropout=0):
            super(self.__class__, self).__init__()
            # self.gene_emd_dim = gene_emd_dim
            # self.geneLayers = [geneInput_dim] + geneEncodeLayer + [gene_emd_dim]
            self.activation = activation
            self.dropout = dropout

            self.geneencoder = buildNetwork_gene([geneInput_dim] + geneEncodeLayer, activation=activation,
                                                 dropout=dropout)
            self.genedecoder = buildNetwork_gene(geneDecodeLayer, activation=activation, dropout=dropout)
            # self._enc_mu_gene = nn.Linear(geneEncodeLayer[-1], gene_emd_dim)
            self._dec_gene = nn.Linear(geneDecodeLayer[-1], geneInput_dim)

        def forward(self, genetocell):
            h = self.geneencoder(genetocell)
            # z = self._enc_mu(h)
            h = self.genedecoder(h)
            xrecon = self._dec_gene(h)
            # compute q -> NxK
            # q = self.soft_assign(z)
            return xrecon

    def normalize(adata, filter_min_counts=True, size_factors=True, normalize_input=True, logtrans_input=True):
        if filter_min_counts:
            sc.pp.filter_genes(adata, min_counts=1)
            sc.pp.filter_cells(adata, min_counts=1)

        if size_factors or normalize_input or logtrans_input:
            adata.raw = adata.copy()
        else:
            adata.raw = adata

        if size_factors:
            sc.pp.normalize_per_cell(adata)
            adata.obs['size_factors'] = adata.obs.n_counts / np.median(adata.obs.n_counts)
        else:
            adata.obs['size_factors'] = 1.0

        if logtrans_input:
            sc.pp.log1p(adata)

        if normalize_input:
            sc.pp.scale(adata)

        return adata

    def acc(y_true, y_pred):
        """
        Calculate clustering accuracy. Require scikit-learn installed
        # Arguments
            y: true labels, numpy.array with shape `(n_samples,)`
            y_pred: predicted labels, numpy.array with shape `(n_samples,)`
        # Return
            accuracy, in [0,1]
        """
        y_true = y_true.astype(np.int64)
        assert y_pred.size == y_true.size
        D = max(y_pred.max(), y_true.max()) + 1
        w = np.zeros((D, D), dtype=np.int64)
        for i in range(y_pred.size):
            w[y_pred[i], y_true[i]] += 1
        # from sklearn.utils.linear_assignment_ import linear_assignment
        from scipy.optimize import linear_sum_assignment as linear_assignment
        ind = linear_assignment(w.max() - w)

        # return sum([w[i, j] for i, j in ind]) * 1.0 / y_pred.size

        b = [None] * len(ind[0])
        for k in range(len(ind[0])):
            i = ind[0][k]
            j = ind[1][k]
            b[k] = w[i, j]
        return sum(b) * 1.0 / y_pred.size

    ### the preprocessing can be changed accorrding your data #########
    # 筛选基因：将基因中非0的个数小于细胞个数0.01倍的基因剔除
    columns = (input != 0).sum(0)
    input = input[:, columns > np.ceil(input.shape[0] * 0.01)]

    adata = sc.AnnData(input)
    adata.obs['Group'] = y_true

    adata = normalize(adata,
                      size_factors=True,
                      normalize_input=False,
                      logtrans_input=True)
    input = torch.from_numpy(adata.X).float()

    #########

    # Hyper Parameters
    LR_pretrain_cell = 0.0001
    LR_pretrain_gene = 0.0001
    Cell_BATCH_SIZE = 512
    Gene_BATCH_SIZE = 1024
    EPOCH_pretrain = 400
    tol_cell = 0.001
    tol_gene = 0.001

    # 生成细胞视图的数据
    loader_cell = Data.DataLoader(
        dataset=input,  # torch TensorDataset format
        batch_size=Cell_BATCH_SIZE,  # mini batch size
        shuffle=False,  # random shuffle for training
        num_workers=2,  # subprocesses for loading data
    )

    # 生成基因视图的数据
    loader_gene = Data.DataLoader(
        dataset=torch.t(input),  # torch TensorDataset format
        batch_size=Gene_BATCH_SIZE,  # mini batch size
        shuffle=False,  # random shuffle for training
        num_workers=2,  # subprocesses for loading data
    )

    from torch.autograd import Variable

    cellautoencoder = CellAutoEncoder(input.shape[1], cellEncodeLayer=[64, 32], cellDecodeLayer=[32, 64],
                                      activation="relu",
                                      dropout=0.1).float()
    print(cellautoencoder)

    # !!!!!!!! Change in here !!!!!!!!! #
    cellautoencoder  # Moves all model parameters and buffers to the GPU.

    celloptimizer = torch.optim.Adam(cellautoencoder.parameters(), lr=LR_pretrain_cell)
    cellloss_func = nn.MSELoss()

    start = time.time()
    for epoch in range(EPOCH_pretrain):  # train entire dataset 3 times
        for step_cell, batch_cell_cpu in enumerate(loader_cell):  # for each training step
            print('Epoch: ', epoch, '| Step_cell: ', step_cell)
            # !!!!!!!! Change in here !!!!!!!!! #
            batch_cell = batch_cell_cpu  # Tensor on GPU
            # celldecoded = cellautoencoder(batch_cell,noise = False,mean=0, stddev=0.01)
            celldecoded = cellautoencoder(batch_cell)
            cellloss = cellloss_func(celldecoded, batch_cell)  # mean square error
            celloptimizer.zero_grad()  # clear gradients for this training step
            cellloss.backward()  # backpropagation, compute gradients
            celloptimizer.step()  # apply gradients

            print('Epoch [{}/{}], Loss: {:.4f}'
                  .format(epoch + 1, EPOCH_pretrain, cellloss.item()))
        if epoch > 0 and cellloss.item() < tol_cell:
            print('cellloss', cellloss.item(), '< tol ', tol_cell)
            print('Reached tolerance threshold. Stopping training.')
            break

    end = time.time()
    cell_time = end - start
    print('cell time:', cell_time)

    geneautoencoder = GeneAutoEncoder(input.shape[0], geneEncodeLayer=[64, 32], geneDecodeLayer=[32, 64],
                                      activation="relu",
                                      dropout=0.1).float()
    print(geneautoencoder)

    geneautoencoder

    geneoptimizer = torch.optim.Adam(geneautoencoder.parameters(), lr=LR_pretrain_gene)
    geneloss_func = nn.MSELoss()

    start = time.time()
    for epoch in range(EPOCH_pretrain):  # train entire dataset 3 times
        for step_gene, batch_gene_cpu in enumerate(loader_gene):
            print('Epoch: ', epoch, '| Step_gene: ', step_gene)
            # !!!!!!!! Change in here !!!!!!!!! #
            batch_gene = batch_gene_cpu  # Tensor on GPU
            # adj = buildGraphNN(batch_gene, 30)
            # adj = normalized(adj)
            # adj = sparse_mx_to_torch_sparse_tensor(adj)

            # genedecoded = geneautoencoder(batch_gene,noise = False,mean=1, stddev=0.01)
            genedecoded = geneautoencoder(batch_gene)
            geneloss = geneloss_func(genedecoded, batch_gene)  # mean square error
            geneoptimizer.zero_grad()  # clear gradients for this training step
            geneloss.backward()  # backpropagation, compute gradients
            geneoptimizer.step()  # apply gradients

            print('Epoch [{}/{}], Loss: {:.4f}'
                  .format(epoch + 1, EPOCH_pretrain, geneloss.item()))
        if epoch > 0 and cellloss.item() < tol_gene:
            print('geneloss', geneloss.item(), '< tol ', tol_gene)
            print('Reached tolerance threshold. Stopping training.')
            break

    end = time.time()
    gene_time = end - start
    print('gene time:', gene_time)

    # 2 ways to save the net
    torch.save(cellautoencoder.state_dict(), save_path1)  # save only the parameters
    torch.save(geneautoencoder.state_dict(), save_path2)  # save only the parameters

    #######################Fit predition#####################
    # %load_ext autoreload
    # %autoreload 2
    from DeepCI import Net

    n_clusters = len(np.unique(y_true))
    print('unique number of label:', n_clusters)
    # Hyper Parameters
    Cell_BATCH_SIZE = 512
    Gene_BATCH_SIZE = 1024
    lr = 0.001
    EPOCH = 400
    update_interval = 5
    tol = 1e-4

    z_dim = 32
    rec_gamma = 1  # 1
    clu_gamma = 10  # 10
    cell_gamma = 1  # 0.1
    gene_gamma = 1  # 1
    alpha = 1
    idec = Net(input.shape[1], input.shape[0], z_dim, n_clusters, cellEncodeLayer=[64, 32], cellDecodeLayer=[32, 64],
               geneEncodeLayer=[64, 32], geneDecodeLayer=[32, 64],
               activation="relu", dropout=0.1, alpha=alpha, rec_gamma=rec_gamma, clu_gamma=clu_gamma,
               cell_gamma=cell_gamma,
               gene_gamma=gene_gamma)
    print(idec)

    # cell_path = '/home/lzl/DFM/simulation_lzl/simulation_scale_network/pretrain_weights/' + allf[i] + '_cellautoencoder_dropout0.1_defultPreproFilter0.005_64_32_buildnetwork_epoch200.pkl'
    # gene_path = '/home/lzl/DFM/simulation_lzl/simulation_scale_network/pretrain_weights/' + allf[i] + '_geneautoencoder_dropout0.1_defultPreproFilter0.005_64_32_buildnetwork_epoch200.pkl'

    idec.load_model(save_path1, save_path2)
    # idec.cuda()

    # start = time.time()

    torch.manual_seed(2)

    input_fina = input
    y = torch.from_numpy(y_true).int()

    # y_pred_origin = idec.fit(input_fina, y, lr, Cell_BATCH_SIZE, Gene_BATCH_SIZE, EPOCH, update_interval, tol,noise = False,mean=1, stddev=0.01)
    y_pred_origin = idec.fit(input_fina, y, lr, Cell_BATCH_SIZE, Gene_BATCH_SIZE, EPOCH, update_interval, tol)

    [xrecon, cell_emb, gene_emb, z, q, _, _] = idec.forward(input_fina, (torch.t(input_fina)))

    y_pred = torch.argmax(q, dim=1).data.cpu().numpy()

    # 绘制聚类图
    tsne = TSNE(n_components=2, random_state=0)

    X_tsne = tsne.fit_transform(cell_emb.detach().numpy())

    plt.figure(figsize=(5, 5))
    # plt.subplot(121)
    labelliat = np.unique(y)
    plt.scatter(X_tsne[:, 0], X_tsne[:, 1], c=y, s=4, alpha=None, marker='o', edgecolors=None)
    # plt.scatter(X_tsne[:, 0], X_tsne[:, 1], c=y_pred, label=labelliat)
    # plt.legend()
    imagePath = './images/'+ dataset_name +'_DeepCI2.jpg'
    plt.savefig(imagePath, dpi=120)
    plt.show()

    nmi = normalized_mutual_info_score(y_true, y_pred)
    ari = adjusted_rand_score(y_true, y_pred)
    acc = acc(y_true, y_pred)
    fmi = metrics.cluster.fowlkes_mallows_score(y_true, y_pred)
    print("acc, nmi, ari, fmi")
    print("acc: " + str(acc))
    print("nmi: " + str(nmi))
    print("ari: " + str(ari))
    print("fmi: " + str(fmi))

    return acc, nmi, ari, fmi


if __name__ == '__main__':
    # datasetnames = ['Quake_10x_Bladder', 'Quake_10x_Limb_Muscle', 'Quake_Smart-seq2_Diaphragm', 'Romanov', 'Young',
    #                 'Adam', 'Bach', 'Chen', 'Plasschaert', 'Quake_10x_Spleen', 'Quake_10x_Trachea',
    #                 'Quake_Smart-seq2_Heart', 'Quake_Smart-seq2_Limb_Muscle', 'Quake_Smart-seq2_Lung', 'Klein',
    #                 'Muraro', 'Pollen', 'Tosches_turtle', 'Wang_Lung']

    datasetnames = ['Romanov', 'Young', 'Adam', 'Quake_Smart-seq2_Limb_Muscle', 'Muraro', 'Pollen', 'Wang_Lung']

    for datasetname in datasetnames:
        # dataset = datasetname
        print("============" + datasetname + "=================")

        # 运行主程序
        results = pd.DataFrame()
        acc, nmi, ari, fmi = main(datasetname)
        results = pd.concat([results, pd.DataFrame([acc, nmi, ari, fmi]).T], 1)
        results.columns = ["acc", "nmi", "ari", "fmi"]
        result_str = datasetname + '\n' + str(results) + '\n'

        with open('./Result/result_GNN_deep_nmf_11--29绘图.txt', 'a') as f:  # 设置文件对象
            f.write(result_str)  # 可以是随便对文件的操作