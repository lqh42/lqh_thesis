#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2023/2/13
# @Author  : 小龙人
# @Github  : https://github.com/lqh42
# @Software: PyCharm
# @File    : LossCalculation.py
import torch
import torch.nn.functional as F
import torch.nn as nn


def target_distribution(q):
    weight = q ** 2 / q.sum(0)
    return (weight.t() / weight.sum(1)).t()


def lossCalculation(input, Cell_bar, Gene_bar,Cell_embedding,Gene_embedding, q, predict, lambda1, alpha, mu, beta):
    # 计算重构结果
    Cell_X = input
    Gene_X = torch.t(input)
    # 计算哈达玛矩阵
    S = Cell_X
    S[S != 0] = 1
    # 通过NMF计算重构
    Cell_re = S * (Cell_embedding @ Gene_embedding.T)

    # 损失函数的计算
    eps = 1e-5

    tmp_q = predict.data
    p = target_distribution(tmp_q)

    # 自监督损失
    kl_loss = F.kl_div(q.log(), p, reduction='batchmean')

    # 重构损失
    Cell_re_loss = F.mse_loss(Cell_bar, Cell_X)
    Gene_re_loss = F.mse_loss(Gene_bar, Gene_X)

    # 增加重构图的损失
    re_loss = F.mse_loss(Cell_re, Cell_X)

    loss = lambda1 * kl_loss + alpha * Cell_re_loss + mu * Gene_re_loss + beta * re_loss
    # loss = lambda1 * kl_loss + lambda1 * ce_loss + alpha * re_loss + mu * likelihood + beta * adj_loss

    return loss
