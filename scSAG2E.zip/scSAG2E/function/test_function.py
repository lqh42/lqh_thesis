#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2023/2/10
# @Author  : 小龙人
# @Github  : https://github.com/lqh42
# @Software: PyCharm
# @File    : test_function.py
'''
这里保存test代码，每次迭代调用一次测试代码
'''

import torch
import numpy as np
from sklearn import metrics

from lib.utils import getResults, buildGraphNN, normalize, sparse_mx_to_torch_sparse_tensor
from sklearn.cluster import KMeans


def target_distribution(q):
    weight = q ** 2 / q.sum(0)
    return (weight.t() / weight.sum(1)).t()


def test(args, iter, test_loader,Gene_test_data, model):
    model.eval()
    # 创建一个predictions来记录我们预测的结果
    predictions = torch.FloatTensor().to(args.device)

    # labels是原本的标签
    labels = torch.FloatTensor().to(args.device)
    with torch.no_grad():  # 是一个上下文管理器，被该语句 wrap 起来的部分将不会track梯度。

        for (input, targets) in test_loader:
            # 数据读取
            Cell_X = input
            targets = targets
            # Cell_X = input
            Gene_X = torch.t(Cell_X)
            adj = buildGraphNN(Gene_X, 50)
            adj = normalize(adj)
            adj = sparse_mx_to_torch_sparse_tensor(adj)

            # adj = buildGraphNN(X, args.neighborK)
            # adj = normalize(adj)
            # adj = sparse_mx_to_torch_sparse_tensor(adj)

            Cell_bar, Gene_bar, Cell_embedding, Gene_embedding, q, predict = model(Cell_X, Gene_X, adj)

            # tmp_q = q.data
            # p = target_distribution(tmp_q)

            # pred_tmp_q = tmp_q.cpu().numpy().argmax(1)

            # pred_tmp_q = torch.argmax(tmp_q, 1).detach().numpy()
            # pred_p = torch.argmax(p, 1).detach().numpy()
            # pred_tmp_predict = torch.argmax(predict, 1).detach().numpy()

            # labels = torch.cat((labels, targets), 0)

            predict = predict.cpu().numpy().argmax(1)
            y_pred = torch.from_numpy(predict)
            predictions = torch.cat((predictions, y_pred), 0)
            labels = torch.cat((labels, targets), 0)

    # 开始计算各个结果参数
    predictions = predictions.numpy().astype(int)
    labels = labels.numpy().astype(int)

    print("---Iter:{} 整体测试集上的报告---".format(iter))
    report = metrics.classification_report(labels, predictions, digits=4)
    print(report)
    acc_for_each_class = metrics.precision_score(labels, predictions, average=None)
    # OA得单独拎出来，因为要计算最优模型
    Result = getResults(predictions, labels)
    test_ACC = Result.at[0, 'acc']
    print("整体测试集上的OA:{}".format(test_ACC))
    test_AA = np.mean(acc_for_each_class)
    print("整体测试集上的AA:{}".format(test_AA))
    test_kappa = metrics.cohen_kappa_score(labels, predictions)
    print("整体测试集上的kappa系数:{}".format(test_kappa))
    print("test_OA={}".format(round(test_ACC, 4)))

    Result = getResults(predictions, labels)

    return test_ACC, test_AA, test_kappa, report, Result
