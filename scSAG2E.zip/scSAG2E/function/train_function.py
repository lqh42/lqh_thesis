#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2023/2/10
# @Author  : 小龙人
# @Github  : https://github.com/lqh42
# @Software: PyCharm
# @File    : train_function.py

# 这里是一个epoch发生的训练
import time
import logging

import numpy as np

from lib.utils import buildGraphNN, normalize, sparse_mx_to_torch_sparse_tensor
from .LossCalculation import lossCalculation
from .val_function import validate
import torch
from tqdm import tqdm


def time_record(start):
    end = time.time()
    duration = end - start
    hour = duration // 3600
    minute = (duration - hour * 3600) // 60
    second = duration - hour * 3600 - minute * 60
    logging.info('Elapsed time: %dh %dmin %ds' % (hour, minute, second))


def train_epoch(Cell_train_data, Gene_train_data, model, optimizer, lambda1, alpha, mu, beta):
    model.train()

    for step_cell, (batch_cell, targets) in enumerate(Cell_train_data):
        # print(str(step) + ": " + str(inputs.shape[0]))
        # 数据读取
        Cell_X = batch_cell
        targets = targets
        for step_gene, batch_gene in enumerate(Gene_train_data):
            # 模型训练
            optimizer.zero_grad()
            Cell_bar, Gene_bar, Cell_embedding, Gene_embedding, q, predict = model(Cell_X)

            # 损失计算

            loss = lossCalculation(Cell_X, Cell_bar, Gene_bar, Cell_embedding, Gene_embedding, q, predict, lambda1,
                                   alpha,
                                   mu, beta)
            loss = loss.detach_().requires_grad_(True)
            loss.backward()
            # loss.backward(retain_graph=True)
            optimizer.step()

    return model, loss


# 我们还需要一个总的训练函数，一次调用就代表我们实验重复一次
def train(args, item, model, Cell_train_loader, Gene_train_loader, optimizer, num_cell,
          scheduler):
    start = time.time()
    epoch_num = args.epochs
    tol = 1e-4
    num_cell = num_cell
    # best_val_OA = 0.0
    # best_model = None

    # 模型加载
    # model.train()

    for epoch in tqdm(range(epoch_num)):

        if epoch % args.update_interval == 0:
            # update the targe distribution p
            latent = model.encodeBatch(Cell_train_loader)
            q = model.soft_assign(latent)
            p = model.target_distribution(q).data

            # evalute the clustering performance
            y_pred = torch.argmax(q, dim=1).data.cpu().numpy()

            # check stop criterion
            delta_label = np.sum(y_pred != y_pred_last).astype(np.float32) / num_cell  ###
            y_pred_last = y_pred
            if epoch > 0 and delta_label < tol:
                print('delta_label ', delta_label, '< tol ', tol)
                print("Reach tolerance threshold. Stopping training.")
                break

        # Choice Model Training
        print(
            '-------Iter:{}....train weights for epoch:{} ... dataset: {}-------'.format(item, epoch + 1, args.dataset))
        model, loss = train_epoch(Cell_train_loader, Gene_train_loader, model, optimizer, args.lambda1, args.alpha,
                                  args.mu, args.beta)

        # 更新学习率计划
        scheduler.step()
        # Choice Model Validation 验证模型
        # val_OA = validate(model, Cell_val_loader, args.neighborK, args.device, args.n_clusters)
        #
        # print('val weights for epoch:{},val_OA={}, loss={}'.format(epoch + 1, val_OA, loss))
        # # Save Best Model Weights
        # if best_val_OA <= val_OA:
        #     best_val_OA = val_OA
        #     best_model = model
        #     print('Best val_OA by now,update the best model')
    #
    # print('*****Iter:{}....This iteration has ended, best_val_OA:{}, , return the best model*****'.format(item,
    #                                                                                                       best_val_OA))
    # Record Time
    time_record(start)
    # 这里只需要返回我们训练的最好权重即可
    return model
