#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2023/6/27
# @Author  : 小龙人
# @Github  : https://github.com/lqh42
# @Software: PyCharm
# @File    : pre_train.py



def pre_train():


    return 0