#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2023/2/12
# @Author  : 小龙人
# @Github  : https://github.com/lqh42
# @Software: PyCharm
# @File    : val_function.py
'''
在val验证当前model的函数
输入：model,valloader,
返回：OA
'''
import torch
from sklearn import metrics

from lib.utils import getResults, buildGraphNN, normalize, sparse_mx_to_torch_sparse_tensor
from sklearn.cluster import KMeans


def target_distribution(q):
    weight = q ** 2 / q.sum(0)
    return (weight.t() / weight.sum(1)).t()


def validate(model, loader, neighborK, device, n_clusters):
    model.eval()
    # 创建一个predictions来记录我们预测的结果
    predictions = torch.FloatTensor()
    # labels是原本的标签
    labels = torch.FloatTensor()
    # 测试部分主体

    with torch.no_grad():
        for (inputs, targets) in loader:
            # 数据读取
            Cell_X = inputs
            targets = targets
            # Cell_X = input
            Gene_X = torch.t(Cell_X)
            adj = buildGraphNN(Gene_X, 50)
            adj = normalize(adj)
            adj = sparse_mx_to_torch_sparse_tensor(adj)

            # 验证得到嵌入特征

            Cell_bar, Gene_bar, Cell_embedding, Gene_embedding, q, predict = model(Cell_X, Gene_X, adj)

            predict = predict.cpu().numpy().argmax(1)

            y_pred = torch.from_numpy(predict)
            predictions = torch.cat((predictions, y_pred), 0)
            labels = torch.cat((labels, targets), 0)
            # kmeans

            # embedding = h
            # clt = KMeans(n_clusters=n_clusters, init='k-means++')
            # y_pred = clt.fit_predict(embedding)
            # y_pred = torch.from_numpy(y_pred)
            # predictions = torch.cat((predictions, y_pred), 0)
            # labels = torch.cat((labels, targets), 0)

    predictions = predictions.numpy()
    labels = labels.numpy().astype(int)
    Result = getResults(predictions, labels)
    OA = Result.at[0, 'acc'] * 100
    OA = round(OA, 2)
    return OA
