#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2023/7/13
# @Author  : 小龙人
# @Github  : https://github.com/lqh42
# @Software: PyCharm
# @File    : Kmeans.py

# dataPath = "/Users/lqh/Desktop/DeepLearningCode/Data/SingleCell_h5_Data"
# # dataset = "Quake_10x_Limb_Muscle"
# dataset = dataset_name
# filename = dataPath + "/" + dataset + "/data.h5"
# input, y_true, _, _, _ = preprocessH5.load_h5(filename, 2000)

# import os
# os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from numpy import nonzero
from sklearn.cluster import KMeans
from sklearn.metrics import f1_score, accuracy_score, normalized_mutual_info_score, rand_score
# from sklearn.preprocessing import LabelEncoder
from sklearn.decomposition import PCA

from lib import preprocessH5
from lib.preprocessH5 import prepro

# df_full = pd.read_csv("iris.csv")  # 鸢尾花数据集 Iris  class=3
# df_full = pd.read_csv("wine.csv")  # 葡萄酒数据集 Wine  class=3
# df_full = pd.read_csv("seeds.csv")  # 小麦种子数据集 seeds  class=3
# df_full = pd.read_csv("wdbc.csv")  # 威斯康星州乳腺癌数据集 Breast Cancer Wisconsin (Diagnostic)  class=2
# #
dataset_name = 'Quake_10x_Limb_Muscle'
dataPath = "/Users/lqh/Desktop/DeepLearningCode/Data/SingleCell_h5_Data"
# dataset = "Quake_10x_Limb_Muscle"
dataset = dataset_name
filename = dataPath + "/" + dataset + "/data.h5"
# df_full, y_true, _, _, _ = preprocessH5.load_h5(filename, 2000)
df_full, y_true, = prepro(filename)

n_clusters = len(np.unique(y_true))
df = df_full
class_labels = y_true
K = n_clusters
# df = PCA(n_components=500).fit_transform(df)  # 降维
# # 原始代码
# columns = list(df_full.columns)  # 获取数据集的第一行，第一行通常为特征名，所以先取出
# features = columns[:len(columns) - 1]  # 数据集的特征名（去除了最后一列，因为最后一列存放的是标签，不是数据）
# df = df_full[features]  # 预处理之后的数据，去除掉了第一行的数据（因为其为特征名，如果数据第一行不是特征名，可跳过这一步）
#
# class_labels = list(df_full[columns[-1]])  # 原始标签
#
# if type(class_labels[0]) != int:
#     class_labels = LabelEncoder().fit_transform(df_full[columns[len(columns)-1]])  # 如果标签为文本类型，把文本标签转换为数字标签
#     print("此数据集标签为文本类型，已经转化为数字标签！")
# K = 3



# 这里已经知道了分3类，其他分类这里的参数需要调试
model = KMeans(n_clusters=K)
# 训练模型
model.fit(df)
# 预测全部数据
label = model.predict(df)
print(label)


def clustering_indicators(labels_true, labels_pred):
    f_measure = f1_score(labels_true, labels_pred, average='macro')  # F值
    accuracy = accuracy_score(labels_true, labels_pred)  # ACC
    normalized_mutual_information = normalized_mutual_info_score(labels_true, labels_pred)  # NMI
    rand_index = rand_score(labels_true, labels_pred)  # RI
    return f_measure, accuracy, normalized_mutual_information, rand_index


F_measure, ACC, NMI, RI = clustering_indicators(class_labels, label)
print("F_measure:", F_measure, "ACC:", ACC, "NMI", NMI, "RI", RI)
data_reduced = PCA(n_components=2).fit_transform(df)  # 降维

# 打印出聚类散点图
plt.scatter(data_reduced[:, 0], data_reduced[:, 1], marker='o', c=label, s=4)  # 原图
plt.show()
# plt.scatter(data_reduced[nonzero(label == 0), 0], data_reduced[nonzero(label == 0), 1], c='red', s=7)
# plt.scatter(data_reduced[nonzero(label == 1), 0], data_reduced[nonzero(label == 1), 1], c='blue', s=7)
# plt.scatter(data_reduced[nonzero(label == 2), 0], data_reduced[nonzero(label == 2), 1], c='green', s=7)
# plt.show()

