import os

import pandas as pd
import torch
from enum import unique
from matplotlib import pyplot as plt
from sklearn import metrics
from sklearn.cluster import KMeans
from sklearn.manifold import TSNE
from sklearn.metrics import normalized_mutual_info_score, adjusted_rand_score
import scipy.io as scio
import numpy as np

# from Dataset import Dataset
# from preprocessH5 import load_h5, prepro
import scanpy as sc

from lib.preprocessH5 import prepro


def cluster_acc(y_pred, y_true):
    """
    Calculate clustering accuracy. Require scikit-learn installed
    # Arguments
        y: true labels, numpy.array with shape `(n_samples,)`
        y_pred: predicted labels, numpy.array with shape `(n_samples,)`
    # Return
        accuracy, in [0,1]
    """

    if type(y_pred) is not torch.Tensor:
        y_pred = torch.LongTensor(y_pred)
    if type(y_true) is not torch.Tensor:
        y_true = torch.LongTensor(y_true)

    y_pred = y_pred.type_as(y_true)

    y_pred = y_pred.cpu().numpy()
    y_true = y_true.cpu().numpy()

    assert y_pred.size == y_true.size
    D = max(y_pred.max(), y_true.max()) + 1
    w = np.zeros((D, D), dtype=np.int64)
    for i in range(y_pred.size):
        w[y_pred[i], y_true[i]] += 1
    # from sklearn.utils.linear_assignment_ import linear_assignment
    from scipy.optimize import linear_sum_assignment as linear_assignment
    ind = linear_assignment(w.max() - w)
    my_acc = sum([w[i, j] for i, j in enumerate(ind[1])]) * 1.0 / y_pred.size

    return my_acc


def cluster_ari_nmi_fmi(y_pred, y_true):
    """
    Calculate clustering accuracy. Require scikit-learn installed
    # Arguments
        y: true labels, numpy.array with shape `(n_samples,)`
        y_pred: predicted labels, numpy.array with shape `(n_samples,)`
    # Return
        accuracy, in [0,1]
    """

    if type(y_pred) is not torch.Tensor:
        y_pred = torch.LongTensor(y_pred)
    if type(y_true) is not torch.Tensor:
        y_true = torch.LongTensor(y_true)

    y_pred = y_pred.type_as(y_true)

    y_pred = y_pred.cpu().numpy()
    y_true = y_true.cpu().numpy()

    ari_test = metrics.adjusted_rand_score(y_true, y_pred)
    nmi_test = metrics.normalized_mutual_info_score(y_true, y_pred)
    fmi_test = metrics.cluster.fowlkes_mallows_score(y_true, y_pred)

    return ari_test, nmi_test, fmi_test


# DATA = scio.loadmat('C:\\Users\\melonn\\Desktop\\code\\Multi-VAE-main\\utils\\DATA\\MNIST10000.mat')
#
# X = DATA['X1']
# X=X.reshape(10000,1024)
# y_true=DATA['Y']
# y_true=y_true[0]
# # set the number of clusters

ARI = []
ACC = []
NMI = []
FMI = []
NAME = []
device = torch.device("cuda")
# for name in ['Quake_Smart-seq2_Diaphragm','Quake_10x_Bladder','Klein','Quake_10x_Limb_Muscle','Plasschaert','Quake_Smart-seq2_Heart','Wang_Lung',
#                  'Muraro','Adam','Bach','Chen','Pollen','Quake_10x_Spleen','Quake_10x_Trachea','Quake_Smart-seq2_Lung','Quake_Smart-seq2_Trachea',
#                  'Romanov','Tosches_turtle','Young','Quake_Smart-seq2_Limb_Muscle']:
# dataset_name = 'Quake_10x_Limb_Muscle'
# dataPath = "/Users/lqh/Desktop/DeepLearningCode/Data/SingleCell_h5_Data"
# # dataset = "Quake_10x_Limb_Muscle"
# dataset = dataset_name
# filename = dataPath + "/" + dataset + "/data.h5"

datasetnames = ['Romanov', 'Young', 'Adam', 'Quake_Smart-seq2_Limb_Muscle', 'Muraro', 'Pollen', 'Wang_Lung']
dataPath = "/Users/lqh/Desktop/DeepLearningCode/Data/SingleCell_h5_Data"
for name in datasetnames:
    # file = os.path.dirname(os.path.dirname(os.getcwd())) + '/dataset' + '/' + name + '/data.h5'

    filename = dataPath + "/" + name + "/data.h5"
    X, Y = prepro(filename)
    # adata,X ,Y,_,_,_  = prepro(file)

    y_true = Y

    n_clusters = len(np.unique(y_true))

    # initialize the k-means model
    kmeans = KMeans(n_clusters=n_clusters, random_state=42)

    # fit the model to the data
    v = kmeans.fit(X)
    # get the predicted cluster labels
    y_pred = kmeans.predict(X)

    # adata_view = adata
    # outdir = os.getcwd() + '/out_final_kmeans_B'
    # embed = 'UMAP'
    # adata_view.obsm['latent'] = X
    # # adata_view.obs['celltype'] = labels.cpu().numpy()
    # adata_view.obs['celltype'] = y_pred
    # sc.pp.neighbors(adata_view, n_neighbors=30, use_rep='latent')
    # if not os.path.exists(outdir):
    #         os.makedirs(outdir)
    #         sc.set_figure_params(dpi=80, figsize=(6, 6), fontsize=10)
    # if outdir:
    #         sc.settings.figdir = outdir
    #         save = '.svg'
    # else:
    #         save = None
    # if embed == 'UMAP':
    #         sc.tl.umap(adata_view, min_dist=0.1)
    #         color = [c for c in ['celltype', 'kmeans', 'leiden', 'cell_type'] if c in adata_view.obs]
    #         sc.pl.umap(adata_view, color=color, save=save, show=False, wspace=0.4, ncols=4)
    # elif embed == 'tSNE':
    #         sc.tl.tsne(adata_view, use_rep='latent')
    #         color = [c for c in ['celltype', 'kmeans', 'leiden', 'cell_type'] if c in adata_view.obs]
    #         sc.pl.tsne(adata_view, color=color, save=save, show=False, wspace=0.4, ncols=4)

    X = X
    labels = y_pred
    tsne = TSNE(n_components=2, random_state=0)
    Y = tsne.fit_transform(X)
    # x_min, x_max = Y.min(0), Y.max(0)
    # X_norm = (Y - x_min) / (x_max - x_min)

    area = (20 * np.random.rand(len(Y))) ** 2
    # color = []
    #
    # for i in np.arange(len(y_pred)):
    #         if labels[i] == 0:
    #                 color.append('darkgreen')
    #         if labels[i] == 1:
    #                 color.append('darkorchid')
    #         if labels[i] == 2:
    #                 color.append('darkgoldenrod')
    #         if labels[i] == 3:
    #                 color.append('darkred')
    #         if labels[i] == 4:
    #                 color.append('royalblue')
    #         # cornflowerblue

    # color = len(y_pred)

    # plt.scatter(Y[:, 0], Y[:, 1], c=color, s=area, alpha=None, marker='o', edgecolors='white')
    plt.figure(figsize=(5, 5))
    plt.scatter(Y[:, 0], Y[:, 1], c=[y_pred], s=4, alpha=None, marker='o')
    filename = name + '_Kmeans' + '.jpg'
    plt.savefig(filename, dpi=120)

    plt.show()

    # compute clustering performance metrics
    acc = cluster_acc(y_pred, y_true)
    ari, nmi, fmi = cluster_ari_nmi_fmi(y_pred, y_true)

    NAME.append(name)
    ACC.append(acc)
    ARI.append(ari)
    NMI.append(nmi)
    FMI.append(fmi)
    print("----------" + name + "-----finished-------------------------")

dict = {'name': NAME, 'acc': ACC, 'ari': ARI, 'nmi': NMI, 'fmi': FMI}
df = pd.DataFrame(dict)
df.to_csv('result_2.csv')

df = pd.read_csv('result_2.csv')

print(df)
